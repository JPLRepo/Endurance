This work is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License.

This package redistributes the following mods and plugins, their license information can be found in the provided links:

Firespitter by Snjo - http://forum.kerbalspaceprogram.com/threads/24551-Firespitter-propeller-plane-and-helicopter-parts-v7-1-%28May-5th%29-for-KSP-1-0

LayeredAnimations by Starwaster - https://github.com/Starwaster/LayeredAnimations